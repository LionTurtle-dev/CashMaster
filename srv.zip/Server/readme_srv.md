# CashMaster adatszerkezete

## **keszlet.json**

**[HUN]**

### ADATSZERKEZET:
```	
{
	//Eredeti darabszám
	"Árlista": [ 
		["termék", ár, darabszám],
		["termék", ár, darabszán]
	],
	//Vásárlásból megmaradt készlet
	"megmaradt": [
		["termék", ár, darabszám],
		["termék", ár, darabszán]
	],
	//Eladások vevőnként
	"tranzakciók": [
		{"cuccok": [
			>Vásárlások, befizetett összeggel
			["termék", ár, darabszám, összeg],
			["termék", ár, darabszám, összeg]
		]}
	],
	//A kifizetett árukból befolyó összeg
	"bevétel": szám
}
```

**[ENG]**

### DATA STRUCTURE:
```
{
	//Original measure of products(lists of products)
	"Árlista": [
	//[product, price, number of pieces]
		["product", price, numper of piece],
		["product", price, numper of piece]
	],
	//Retained products
	"megmaradt": [
		["product", price, numper of piece],
		["product", price, numper of piece]
	],
	//Transactions by clients
	"tranzakciók": [
		{
			"cuccok": [
				["product", price, numper of piece],
				["product", price, numper of piece]
			]
		},
		{
			"cuccok": [
				["product", price, numper of piece],
				["product", price, numper of piece]
			]
		}
	],
	//Sum of income(number)
	"bevétel": szám
}
```
======================================================

## **server.py**

[HUN]
##### *(http szerver futtatása az árúkészlet eléréséhez)*

-SZERVER FUTTATÁSA AZ ADATOK ELÉRÉSÉHEZ:<br><br>
	~ Ahhoz, hogy a program be tudja olvasni az adatokat, egy http szervert kell futtatnod. Ehhez készült a server.py file. Ezzel a python programmal egy http szervert indíthatsz el, amivel a CashMaster program kommunikál.<br><br>
	Ez azért fontos, mert az árúkészlet adatait a keszlet.json file tárolja.

-WINDOWS:<br><br>
	~ Ha már a Server mappában vagy, kattints az egér jobb gombjával és válaszd a "Megnyitás terminálban" lehetőséget!<br><br>
	~ Kattints a hálózatok ikonjára alul, a tálcán, az óra mellett! A Wi-fi ikon mellett van egy kacsacsőr, amire rákattintva megtalálod azt a hálózatot, amire rácsatlakoztál. Kattints a jobb-
	felső sarokban lévő, bekarikázott i betűre!<br>
	Ez elnavigál téged a Gépház hálózati beállításaihoz, ahol minden információt megtalálsz a hálózatról.<br>
	Neked az IPv4 címre lesz szükséged. Ott találod meg a géped IP címét.<br><br>
	~ Ha megvan az IP cím, futtatsd a Server mappában a
>`python3 server.py`

<t->
	parancsot! Itt a továbbiakban nem lesz teendőd, a szerver fut az 5555-ös porton. Ha végeztél, a Ctrl + C billentyűkombinációval, le tudod állítani a szervert.

-LINUX:<br><br>
	~ Lépj a Server mappába terminálon keresztül!<br><br>
	~ Linux terminálban az
>`ifconfig`

<t->
	parancsot kell használnod. Előfordulhat, hogy a te disztribuciód nem ismeri ezt a parancsot. Nincs ezzel gond, telepítheted a rendszer csomagkezelőjével(apt/apk/pkg/stb...). Itt a 'wlp' vagy 'wlan' blokkot kell keresned, azon belül is az 'inet' kezdetű sort. Közvetlen' az 'inet' után találod az IP címet.<br><br>
	~ Ha már kimásoltad az IP címet, ugyanúgy futtatsd a server.py filet, a
>`python3 server.py`

<t->
	paranccsal! Ha le akarod állítani a szervert, nyomd ugyanúgy a Ctrl + C billentyűket, mint windiws parancssorban!

[ENG]

##### *(Run http server to reach data of products)*

-RUN SERVER, FOR REACH DATAS:<br><br>
	~ You need to run a http server, to the program can read the datas. For this goal I have made server.py file. By this python program, you can start a http server, that the main program communicate with.<br>
	This is important, because of keszlet.json, that contains the datas of the products.

-WINDOWS:<br><br>
	~ In the Server folder you can open the terminal by right click and choose "open in terminal" option.<br><br>
	~ Click the icon of networks near the clock at bottom! Near the Wi-Fi icon you can see a > sign, that if you click on, you will find the network, that you have connected to. Click on the spell of i in the circle, for go to the network settings!<br>
	At there you can see a lot of information of your network. You will need for the IPv4 address.
	There you will find the IP address of your computer.<br><br>
	~ Type the following command:
>`ipconfig`

<t->
	Look for a block where you see row of numbers separated by dots(these numberrows are the IP addresses)! You will need for the row of IPv4, probably in the block of "Wireless LAN adapter Wi-Fi". This is IP address of your computer in the Wi-Fi network. Copy the address by Ctrl + C hotkey! The CashMaster reach the data of products on this address.<br><br>
	~ If you have got the IP address, type the following command in the Server folder:
>`python3 server.py`

<t->
	At this point you do not need to do anything, the server is running. If you have finnished, you can stop the server by Ctrl + C hotkey.

-LINUX:<br><br>
	~ On Linux the method will similar to the upper one. Change directory to the Server folder in terminal!<br><br>
	~ In Linux terminal use command of:
>`ifconfig`

<t->
	Your distribution maybe does not know this command, but you can install it by package manager of the sysem(apt/apk/pkg/etc...). At here you must find the block of 'wlp' or 'wlan'. At the row of 'inet' you will find the IP address.<br><br>
	~ If you have already fopied the IP address, run the server.py file by
>`python3 server.py`

<t->
	prompt! You can stop the server by Ctrl + C hotkey on Linux too.


======================================================
<br>

## **reboot.py**

[HUN]

##### *(A készlet adatainak visszaállítása alaphelyzetbe)*

-LINUX/WINDOWS:<br><br>
	~ Nyitsd meg a Server mappát terminálban! Írd be a következő utasítást:
>`python3 reboot.py`

<t->
	~ A program megkérdezi, hogy melyik állományt akarod visszaállítani alaphelyzetbe. Ha semmit nem írsz be, alapértelmezetten a keszlet.json állománynyal fog dolgozni. Ha készítettél egy másik állományt ugyanezzel a felépítéssel, annak a nevét is beírhatod, majd
	nyomj Entert!<br><br>
	~ Ennek hatására a "megmaradt" részben lévő adatokat a program átírja az "árlista" résszel megegyezőre, törli az összes tranzakciót és a "bevétel" számlálóját nullára állítja és kiírja, hogy a műveletet sikeresen végrehajtotta.


[ENG]

##### *(Reset datas of the products to the original state)*

-LINUX/WINDOWS:<br><br>
	~ Open the Server folder in terminal and type the following command:
>`python3 reboot.py`

<t->
	~ The program will ask you, to which file do you reset. If you type nothing, the program will work with the keszlet.json file. If you have made another datafile with the same structure, you can type the name of that file too, then press Enter!<br><br>
	~ By this way, the datas in the part of "megmaradt" the program writes to the same as the part of "árlista", delete all of the transactions and set the counter of "bevétel" to zero. After the completed work prints to reset completed in Hungarian. (The english version is coming soon...)
