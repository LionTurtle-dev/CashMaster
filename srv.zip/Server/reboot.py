import json
fl = input('Add meg a kezelendő jSON file nevét! -> ')
fl = "keszlet.json" if fl == '' else fl
adat = None

try:
    with open(fl, encoding="utf-8") as file:
        adat = json.load(file)

    adat["megmaradt"] = adat["árlista"]
    adat["tranzakciók"] = []
    adat["bevétel"] = 0

    with open(fl, 'w', encoding='utf-8') as f:
        json.dump(adat, f, indent=4)

    print(f"\n{fl} adatainak visszaállítása alaphelyzetbe\nsikeresen megtörtént.\n")

except FileNotFoundError:
    if fl == "keszlet.json":
        print("\nBaj van!\nNincs meg a „keszlet.json” nevű állomány. Lehet, hogy véletlenül törölted, vagy áthelyezted máshová.\nNézd meg a géped keresőjében, hogy megvan e! Ha nincs, töltsd le újra a programot!\n")
    else:
        print(f"\nHoppá!\nA(z) „{fl}” nevű file nem található.\nHa a „keszlet.json” nevű file adatait akarod visszaállítani,\nakkor a legegyszerűbb, ha semmit nem írsz az input mezőbe.\n")

